import './Textbox.css'
import Button from './Button';
export default function Textbox(props)
{
    return (
        <div className='text_box'>
            <div className="head">
                <h1 className='h1'>{props.line1} <br/> {props.line2} </h1>
                <h4 className='h4'>{props.line3} <br/> {props.line4}</h4>
            </div>
            <div className="button1">
                <Button text='LOGIN' fun={()=>{prompt('Enter Email ID to subscribe:');}}/>
            </div>
        </div>
    )
}