import './Button.css'
export default function Button(props)
{
    return(
        <button className="blue_button" onClick={props.fun}>{props.text}</button>
    )
}