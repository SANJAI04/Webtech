import './App.css';
import { Routes,Route } from 'react-router-dom';
import Layout from './routes/Layout';
import Security from './routes/Security';
import Blog from './routes/Blog';
import Product from './routes/Product';
import Plans from './routes/Plansandpricing';
import Password from './routes/Password';
import Home from './routes/Home';

function App() {
  return (
  
    <Routes>
        <Route path='/' element={<Layout/>}>
            <Route index  element={<Home/>}/>
            <Route path='Plans&Pricing' element={<Plans/>}/>
            <Route path='Product Tour' element={<Product/>}/>
            <Route path='Blog' element={<Blog/>}/>
            <Route path='Security' element={<Security/>}/>
            <Route path='Password' element={<Password/>}/>
        </Route>
        
    </Routes>
  
  );
}

export default App;
