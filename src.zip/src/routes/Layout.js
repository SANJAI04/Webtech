import { Outlet,Link } from "react-router-dom";
import './Layout.css';
import Password from '../images/password.jpg';
export default function layout(){
    return (
    <div className="mainContainer">
        <div className="Page">
            <div className="Header">
                <div className="icon">
                    <Link to='/'>
                        <img src={Password} className="logo"/>
                    </Link>
                </div>
                <div className="list">
                    <Link to='/Plans&Pricing'>Plans & Pricing</Link>
                    <Link to='/Product Tour'>Product Tour</Link>
                    <Link to='/Blog'>Blog</Link>
                    <Link to='/Security'>Security</Link>
                    <Link to='Password'>Password Generator</Link>
                    <a>Customers</a>
                    <a>Help</a>
                    <a>+124 123971 134</a>
                    
                </div>
                
            </div>

            <div className="Body">
                <Outlet/>
            </div>

            <div className="footer">

            </div>
        </div>
    </div>
    )
}