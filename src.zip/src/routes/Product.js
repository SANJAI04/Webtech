export default function Product()
{
    return (<></>)
}