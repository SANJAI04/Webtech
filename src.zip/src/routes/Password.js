export default function Password(){
    return (<h1>Password</h1>)
}