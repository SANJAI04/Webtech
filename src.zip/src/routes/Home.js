import Home_img from '../images/home_img.png'
import './Home.css'
import Textbox from '../components/Textbox'
import Home_img2 from '../images/home 2.png'
export default function Home(){
    return (
    <>
        <Textbox line1 = 'The Password ' line2='Manager for Teams' line3='TeamPassword is the fastest, easiest and most secure way' line4='to store and share team logins and passwords.' />
        <img src={Home_img} className='Home_img'/>
        <img src={Home_img2} className='Home_img'/>
    </>)
}